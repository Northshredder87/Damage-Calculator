var MOVES_SM = {
    '(No Move)': {
        bp: 0,
        type: 'Normal',
        category: 'Physical'
    },
    'Needlespray': {
        bp: 0,
        type: 'Grass',
        category: 'Physical'
    },
};
